//
//  Auth_Web_UIApp.swift
//  Auth-Web-UI
//
//  Created by Kyle Lee on 7/29/20.
//

import SwiftUI

@main
struct Auth_Web_UIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
