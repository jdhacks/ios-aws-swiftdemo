//
//  ContentView.swift
//  Auth-Web-UI
//
//  Created by Kyle Lee on 7/29/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!").padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
